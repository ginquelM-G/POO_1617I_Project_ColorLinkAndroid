package pt.isel.poo.colorlink.editor;

/**
 * Created by Moreira on 09/01/2017.
 */

public class PieceModel {
}
